-- Gerado por Oracle SQL Developer Data Modeler 22.2.0.165.1149
--   em:        2022-11-28 15:46:23 BRT
--   site:      Oracle Database 11g
--   tipo:      Oracle Database 11g

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE dim_cliente (
    sk_cliente                 NUMBER(10) NOT NULL,
    nr_cliente                 NUMBER(10) NOT NULL,
    nm_cliente                 VARCHAR2(80) NOT NULL,
    qt_estrelas                NUMBER(1),
    tp_cliente_fisica_juridica CHAR(1) NOT NULL,
    nr_cpf                     NUMBER(11),
    dt_nascimento              DATE,
    nr_cnpj                    NUMBER(14),
    nr_inscr_est               VARCHAR2(15),
    dt_fundacao                DATE,
    fl_sexo_biologico          CHAR(1),
    ds_genero                  VARCHAR2(20),
    dt_inicio_endereco         DATE NOT NULL,
    vl_medio_compra            NUMBER(10, 2),
    nr_telefone                VARCHAR2(20),
    nm_login                   VARCHAR2(50) NOT NULL,
    ds_senha                   VARCHAR2(50) NOT NULL
);

COMMENT ON COLUMN dim_cliente.sk_cliente IS
    'Essa coluna ir� armazenar a chave Surrogate da tabela Dimensao Cliente. Campo numerico sequencial';

COMMENT ON COLUMN dim_cliente.nr_cliente IS
    'Essa coluna ir� armazenar o c�digo �nico do cliente na plataforma ecommerce da Melhores Compras. Seu conte�do deve ser obrigat�rio'
    ;

COMMENT ON COLUMN dim_cliente.nm_cliente IS
    'Essa coluna ir� armazenar o nome do cliente na plataforma ecommerce da Melhores Compras. Seu conte�do deve ser obrigat�rio.';

COMMENT ON COLUMN dim_cliente.qt_estrelas IS
    'Essa coluna ir� armazenar a quantiade de estrelas do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio e ser poss�vel de estar entre 1 e 5 estrelas.'
    ;

COMMENT ON COLUMN dim_cliente.tp_cliente_fisica_juridica IS
    'Essa coluna ir� armazenar o status de tipo de cliente da Melhores Compras. Campo de escolha de 1 Caracter
Cliente Pessoa Fisica (F)
Cliente Juridico (J)';

COMMENT ON COLUMN dim_cliente.nr_cpf IS
    'Essa coluna ir� armazenar o n�mero do CPF do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio caso cliente fisico.'
    ;

COMMENT ON COLUMN dim_cliente.dt_nascimento IS
    'Essa coluna ir� armazenar a data de nascimento do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio caso cliente fisico'
    ;

COMMENT ON COLUMN dim_cliente.nr_cnpj IS
    'Essa coluna ir� armazenar o  numero do CNPJ do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio caso cliente juridico'
    ;

COMMENT ON COLUMN dim_cliente.nr_inscr_est IS
    'Essa coluna ir� armazenar o  numero da Inscri��o Estadual  do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser opcional'
    ;

COMMENT ON COLUMN dim_cliente.dt_fundacao IS
    'Essa coluna ir� armazenar data  de funda��o do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio caso cliente juridico'
    ;

COMMENT ON COLUMN dim_cliente.fl_sexo_biologico IS
    'Essa coluna ir� armazenar o sexo biol�gico do cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio. Campo escolha de 1 caracteres.

Feminino (F)
Masculino (M)
';

COMMENT ON COLUMN dim_cliente.ds_genero IS
    'Genero do sexo do Cliente. Seu conte�do deve ser obrigat�rio.';

COMMENT ON COLUMN dim_cliente.dt_inicio_endereco IS
    'Data de in�cio do endere�o associado ao cliente.
Campo alimentado pela tabela T_MC_END_CLI';

COMMENT ON COLUMN dim_cliente.vl_medio_compra IS
    'Essa coluna ir� armazenar o valor  m�dio de gastos f eito pelo cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio e deve ser calculado diariamente.'
    ;

COMMENT ON COLUMN dim_cliente.nr_telefone IS
    'Essa coluna ir� armazenar o n�mero do cliente da Melhorees Compras. A mascara de armazenamento deve ser: (<nr_ddd>) 99999-9999 e  deve ser utilizada pr� definida.'
    ;

COMMENT ON COLUMN dim_cliente.nm_login IS
    'Essa coluna ir� armazenar o login de cada cliente na plataforma ecommerce da Melhores Compras. Seu conte�do deve ser obrigat�rio e  �nico para cada cliente.'
    ;

COMMENT ON COLUMN dim_cliente.ds_senha IS
    'Essa coluna ir� armazenar a senha de cada cliente na plataforma ecommerce da Melhores Compras.Seu conte�do deve ser obrigat�rio.'
    ;

ALTER TABLE dim_cliente ADD CONSTRAINT dim_cliente_pk PRIMARY KEY ( sk_cliente );

CREATE TABLE dim_faixa_etaria (
    sk_faixa_etaria  NUMBER(10) NOT NULL,
    cd_faixa_etaria  NUMBER(5) NOT NULL,
    ds_faixa_etaria  VARCHAR2(40) NOT NULL,
    nr_idade_inicial NUMBER(2) NOT NULL,
    nr_idade_final   NUMBER(2) NOT NULL
);

COMMENT ON COLUMN dim_faixa_etaria.sk_faixa_etaria IS
    'Essa coluna ir� armazenar a chave Surrogate da tabela Dimensao Faixa_Etaria. Campo numerico sequencial';

COMMENT ON COLUMN dim_faixa_etaria.cd_faixa_etaria IS
    'Esse campo ir� armazenar o codigo da Faixa_etaria. Campo numerico

(1)   1 a 20 anos: cliente teen.
(2)   21 a 25 anos: adulta(o) inicio carreira.
(3)   26 a 40 anos: adulta(o) carreira consolidada.
(4)   41 a 60 anos: adulta(o) carreira final.
(5)   61 a 120 anos: adulta(o) terceira idade.
(6)   0 a 0 perfil CNPJ';

COMMENT ON COLUMN dim_faixa_etaria.ds_faixa_etaria IS
    '1 a 20 anos: cliente teen.
21 a 25 anos: adulta(o) inicio carreira.
26 a 40 anos: adulta(o) carreira consolidada.
41 a 60 anos: adulta(o) carreira final.
61 a 120 anos: adulta(o) terceira idade.
0 a 0 perfil CNPJ';

COMMENT ON COLUMN dim_faixa_etaria.nr_idade_inicial IS
    'Esse campo ir� armazenar a idade inicial da Faixa_Etaria, Campo numeric 2 posicoes';

COMMENT ON COLUMN dim_faixa_etaria.nr_idade_final IS
    'Esse campo ir� armazenar a idade final da Faixa_Etaria, Campo numeric 2 posicoes';

ALTER TABLE dim_faixa_etaria ADD CONSTRAINT dim_faixa_etaria_pk PRIMARY KEY ( sk_faixa_etaria );

CREATE TABLE dim_produto (
    sk_produto       NUMBER(10) NOT NULL,
    cd_produto       NUMBER(6) NOT NULL,
    ds_produto       VARCHAR2(50) NOT NULL,
    cd_cat           NUMBER NOT NULL,
    tp_categoria     CHAR(1) NOT NULL,
    ds_categoria     VARCHAR2(500) NOT NULL,
    st_categoria     CHAR(1) NOT NULL,
    vl_unitario      NUMBER(8, 2) NOT NULL,
    tp_embalagem     VARCHAR2(15),
    st_produto       CHAR(1),
    vl_perc_lucro    NUMBER(8, 2),
    ds_completa_prod VARCHAR2(4000) NOT NULL
);

COMMENT ON COLUMN dim_produto.sk_produto IS
    'Essa coluna ir� armazenar a chave Surrogate da tabela Dimensao Produto. Campo numerico sequencial';

COMMENT ON COLUMN dim_produto.cd_produto IS
    'Essa coluna ir� armazenar a chave prim�ria da tabela de produtos da Melhores Compras.';

COMMENT ON COLUMN dim_produto.ds_produto IS
    'Essa coluna ir� armazenar a descri��o principal do produto. Seu conte�do deve ser  obrigatorio.';

COMMENT ON COLUMN dim_produto.cd_cat IS
    'Essa coluna ir� armazenar a chave prim�ria da tabela de categoria de produtos da Melhores Compras.';

COMMENT ON COLUMN dim_produto.tp_categoria IS
    'Nessa  coluna  ser�  armazenada o tipo de categoria que poder�  ser (V)�deo ou (P)rodudto. Seu conte�do deve ser obrigat�rio.';

COMMENT ON COLUMN dim_produto.ds_categoria IS
    'Essa coluna ir� armazenar descri��o da categoria de produtos da Melhores Compras. Cada categoria tem uma  descri��o �nica e serve para organizar os produtos em categorias simliares, melhorando a tomada de decis�o.'
    ;

COMMENT ON COLUMN dim_produto.st_categoria IS
    'Essa coluna ir� armazenar o stauts da categoria da Melhores Compras. Os valores permitidos aqui s�o: A(tivo) e I(nativo).';

COMMENT ON COLUMN dim_produto.vl_unitario IS
    'Essa coluna ir� armazenar o valor unit�rio do produto. Seu conte�do deve ser > 0 ';

COMMENT ON COLUMN dim_produto.tp_embalagem IS
    'Essa coluna ir� armazenar o tipo de embalagem do produto. Seu conte�do pode ser opcional.';

COMMENT ON COLUMN dim_produto.st_produto IS
    'Essa coluna ir� armazenar o stauts do produto da Melhorees Compras. Os valores permitidos aqui s�o: A(tivo) e I(nativo).';

COMMENT ON COLUMN dim_produto.vl_perc_lucro IS
    'Essa coluna ir� armazenar o percentual  do lucro m�dio para cada produto. Seu conte�do deve ser opcional.';

COMMENT ON COLUMN dim_produto.ds_completa_prod IS
    'Essa coluna ir� armazenar a descri��o completa do produto. Seu conte�do deve ser  obrigatorio.';

ALTER TABLE dim_produto ADD CONSTRAINT dim_produto_pk PRIMARY KEY ( sk_produto );

CREATE TABLE dim_regiao (
    sk_regiao NUMBER(10) NOT NULL,
    sg_estado CHAR(2) NOT NULL,
    nm_estado VARCHAR2(30) NOT NULL,
    cd_cidade NUMBER(6) NOT NULL,
    nm_cidade VARCHAR2(40) NOT NULL,
    cd_bairro NUMBER(6) NOT NULL,
    nm_bairro VARCHAR2(40) NOT NULL
);

COMMENT ON COLUMN dim_regiao.sk_regiao IS
    'Essa coluna ir� armazenar a chave Surrogate da tabela Dimensao Regiao. Campo numerico sequencial';

COMMENT ON COLUMN dim_regiao.sg_estado IS
    'Esta coluna ira receber a siga do Estado. Esse conte�do � obrigat�rio.';

COMMENT ON COLUMN dim_regiao.nm_estado IS
    'Esta coluna ir� receber o nome do estado';

COMMENT ON COLUMN dim_regiao.cd_cidade IS
    'Esta coluna ir� receber o codigo da cidade e seu conte�do � obrigat�rio.';

COMMENT ON COLUMN dim_regiao.nm_cidade IS
    'Esta coluna ira receber o nome da Cidade. Esse conte�do � obrigat�rio.';

COMMENT ON COLUMN dim_regiao.cd_bairro IS
    'Esta coluna ir� receber o codigo do bairro e seu conte�do � obrigat�rio.';

COMMENT ON COLUMN dim_regiao.nm_bairro IS
    'Esta coluna ira receber o nome do Bairro. Esse conte�do � obrigat�rio.';

ALTER TABLE dim_regiao ADD CONSTRAINT dim_regiao_pk PRIMARY KEY ( sk_regiao );

CREATE TABLE dim_tempo (
    sk_tempo            NUMBER(10) NOT NULL,
    dt_visualizacao     DATE NOT NULL,
    nr_ano              NUMBER(4) NOT NULL,
    nr_mes              NUMBER(2) NOT NULL,
    nr_dia              NUMBER(2) NOT NULL,
    ds_dia_semana       VARCHAR2(15) NOT NULL,
    nm_mes_extenso      VARCHAR2(18) NOT NULL,
    ds_semestre         VARCHAR2(20) NOT NULL,
    ds_trimestre        VARCHAR2(20) NOT NULL,
    st_feriado_nacional VARCHAR2(3),
    horario_acesso      TIMESTAMP NOT NULL
);

COMMENT ON COLUMN dim_tempo.sk_tempo IS
    'Essa coluna ir� armazenar a chave Surrogate da tabela Dimensao Tempo. Campo numerico sequencial';

COMMENT ON COLUMN dim_tempo.dt_visualizacao IS
    'Esse campo ir� armazenar a data da visualizacao. Campo date, obrigatorio';

COMMENT ON COLUMN dim_tempo.nr_ano IS
    'Esse campo ir� armazenar o ano ex:(2022) da visualizacao. Campo numeric 4 posicoes, obrigatorio.';

COMMENT ON COLUMN dim_tempo.nr_mes IS
    'Esse campo ir� armazenar o mes ex:(08) da visualizacao. Campo numeric 2 posicoes, obrigatorio.';

COMMENT ON COLUMN dim_tempo.nr_dia IS
    'Esse campo ir� armazenar o dia ex:(25) da visualizacao. Campo numeric 2 posicoes, obrigatorio.';

COMMENT ON COLUMN dim_tempo.ds_dia_semana IS
    'Esse campo ir� armazenar o dia da semana por extenso:

Segunda - Feira
Ter�a - Feira
Quarta - Feira
Quinta - Feira
Sexta - Feira
Sabado
Domingo';

COMMENT ON COLUMN dim_tempo.nm_mes_extenso IS
    'Esse campo ir� armazenar o nome do mes por extenso:

Janeiro - Fevereiro - Marco - Abril - Maio - Junho - Julho - Agosto - Setembro - Outubro -
Novembro - Dezembro';

COMMENT ON COLUMN dim_tempo.ds_semestre IS
    'Esse campo ir� armazenar o nome do semestre por extenso:

Primeiro Semestre:   Janeiro - Fevereiro - Marco - Abril - Maio - Junho 

Segundo Semestre: Julho - Agosto - Setembro - Outubro - Novembro - Dezembro';

COMMENT ON COLUMN dim_tempo.ds_trimestre IS
    'Esse campo ir� armazenar o nome do Trimestre por extenso:

Primeiro Trimestre:   Janeiro - Fevereiro - Marco 
Segundo Trimestre: Abril - Maio - Junho 
Terceiro Trimestre: Julho - Agosto - Setembro 
Quarto Trimestre: Outubro - Novembro - Dezembro';

COMMENT ON COLUMN dim_tempo.st_feriado_nacional IS
    'Esse campo ir� armazenar se � feriado nacional: Sim  -  Nao
Campo Varchar de 3 poicoes';

COMMENT ON COLUMN dim_tempo.horario_acesso IS
    'Esse campo ir� armazenar o Horario de acesso detalhado: Hora - Minuto - Segundos.';

ALTER TABLE dim_tempo ADD CONSTRAINT dim_tempo_pk PRIMARY KEY ( sk_tempo );

CREATE TABLE fto_visualizacao_video (
    sk_fato_visualizacao NUMBER(6) NOT NULL,
    cd_visua_video       NUMBER(10) NOT NULL,
    sk_produto           NUMBER(10) NOT NULL,
    sk_cliente           NUMBER(10) NOT NULL,
    sk_regiao            NUMBER(10) NOT NULL,
    sk_tempo             NUMBER(10) NOT NULL,
    sk_faixa_etaria      NUMBER(10) NOT NULL
);

COMMENT ON COLUMN fto_visualizacao_video.sk_fato_visualizacao IS
    'Essa coluna ir� armazenar a chave Surrogate da tabela Fato_Visualizacao_Video. Campo numerico sequencial';

COMMENT ON COLUMN fto_visualizacao_video.cd_visua_video IS
    'Essa coluna ir� armazenar a chave prim�ria da tabela de visualiza��o do v�deo, onde a cada click que o usuario logado ou an�nimo realizar, ser� anotado o acesso realizado.
Conteudo carregado da tabela T_MC_SGV_VISUALIZACAO_VIDEO';

ALTER TABLE fto_visualizacao_video ADD CONSTRAINT fato_visualizacao_pk PRIMARY KEY ( sk_fato_visualizacao );

ALTER TABLE fto_visualizacao_video
    ADD CONSTRAINT dim_cliente_fato FOREIGN KEY ( sk_cliente )
        REFERENCES dim_cliente ( sk_cliente );

ALTER TABLE fto_visualizacao_video
    ADD CONSTRAINT dim_faixa_etaria_tempo FOREIGN KEY ( sk_faixa_etaria )
        REFERENCES dim_faixa_etaria ( sk_faixa_etaria );

ALTER TABLE fto_visualizacao_video
    ADD CONSTRAINT dim_produto_fato FOREIGN KEY ( sk_produto )
        REFERENCES dim_produto ( sk_produto );

ALTER TABLE fto_visualizacao_video
    ADD CONSTRAINT dim_regiao_fato FOREIGN KEY ( sk_regiao )
        REFERENCES dim_regiao ( sk_regiao );

ALTER TABLE fto_visualizacao_video
    ADD CONSTRAINT dim_tempo_fato FOREIGN KEY ( sk_tempo )
        REFERENCES dim_tempo ( sk_tempo );



-- Relat�rio do Resumo do Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                             6
-- CREATE INDEX                             0
-- ALTER TABLE                             11
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
